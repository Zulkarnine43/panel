<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/',[
'uses'=>'MyController@index',
'as'=>'home'
]);

Route::get('/Farmer/signup',[
'uses'=>'MyController@signup',
'as'=>'signup_form'
]);

Route::post('/Farmer/signup/save',[
    'uses'=>'MyController@signup_form_save',
    'as'=>'signup_form_save'
]);

Route::get('/Farmers',[
    'uses'=>'MyController@all_farmers',
    'as'=>'all_farmers'
]);

Route::get('/Farmer/deactive/{id}',[
    'uses'=>'MyController@farmer_deactive',
    'as'=>'farmer_deactive'
]);

Route::get('/Farmer/login/page',[
    'uses'=>'MyController@f_login',
    'as'=>'f_login'
]);

Route::post('/Farmer/login/check',[
    'uses'=>'MyController@f_login_check',
    'as'=>'f_login_check'
]);

Route::get('/Farmer/logout',[
    'uses'=>'MyController@f_logout',
    'as'=>'f_logout'
]);

Route::get('/about',[
    'uses'=>'MyController@about',
    'as'=>'about'
]);
Route::post('/add/cart',[
    'uses'=>'MyController@add_cart',
    'as'=>'add_cart'
]);

Route::get('/verify/mail',[
    'uses'=>'MyController@mail_verify',
    'as'=>'mail_verify'
]);