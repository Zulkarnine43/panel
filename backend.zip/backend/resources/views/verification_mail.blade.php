<h1>To activate Your Account</h1>
<p><a href="{{route('mail_verify')}}">Verify here</a></p>
<h2>Thank You</h2>