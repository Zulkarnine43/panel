@extends('headerFooter');


@section('body')

<table border="5px">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>quentity</th>
        <th>price</th>
        <th>Action</th>
    </tr>
    </thead>
    @php($i=0)

    @foreach($_SESSION['cart'] as $key=>$value)
    <tbody>
    <tr>
        <th>{{  $i++}}</th>
        <th>{{ $value['name']}}</th>
        <th>{{ $value['quentity']}}</th>
        <th>{{ $value['price']*$value['quentity']}}</th>
        <th><a>Edit</a></th>
    </tr>
    </tbody>
        @endforeach
</table>
@endsection