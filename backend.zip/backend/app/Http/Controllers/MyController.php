<?php

namespace App\Http\Controllers;

use App\farmer_login_save;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;

class MyController extends Controller
{
    //
	public function index(){
		
		return view ('index');
		
	}
	
		public function signup(){
		
		return view ('signup');
		
	}
    public function signup_form_save(Request $request){
        
        
    //   $farmer_register=new farmer_login_save();

        // $Activity="active";

        // $farmer_register['f_name']=$request['f_name'];
        // $farmer_register['email']=$request['email'];
        // $farmer_register['phone']=$request['phone'];
        // $farmer_register['district']=$request['district'];
        // $farmer_register['zip_code']=$request['zip_code'];
        // $farmer_register['gender']=$request['gender'];
        // $farmer_register['password']=$request['password'];
        // $farmer_register['confirm_password']=$request['confirm_password'];
        // $farmer_register['Activity']=$Activity;
        // $farmer_register->save();\
        
        
        // ..........sesssion put..........
        
        
        Session::put('f_namee',$request['f_name']);
         Session::put('email',$request['email']);
          Session::put('phone',$request['phone']);
           Session::put('district',$request['district']);
            Session::put('zip_code',$request['zip_code']);
         Session::put('gender',$request['gender']);
          Session::put('password',$request['password']);
           Session::put('confirm_password',$request['confirm_password']);
        
  
        
        $data=$request->toArray();
         Mail::send('verification_mail',$data,function($message) use ($data){
            $message->to($data['email']);
            $message->subject('verification_mail');
        });

        return redirect('/Farmer/signup')->with('regis_success','please verify your email');



    }
    
    
    public function mail_verify(){
        
              $farmer_register=new farmer_login_save();

        $Activity="active";

        $farmer_register['f_name']=Session::get('f_namee');
        $farmer_register['email']=Session::get('email');
        $farmer_register['phone']=Session::get('phone');
        $farmer_register['district']=Session::get('district');
        $farmer_register['zip_code']=Session::get('zip_code');
        $farmer_register['gender']=Session::get('gender');
        $farmer_register['password']=Session::get('password');
        $farmer_register['confirm_password']=Session::get('confirm_password');
        $farmer_register['Activity']=$Activity;
        $farmer_register->save();
        
          return redirect('/Farmer/login/page')->with('verify_success',' verify succesfully, Login here');
        
    }

    public function all_farmers(){

        $Activity="active";
	    $farmers=farmer_login_save::all()->where('Activity',$Activity);

        return view ('all_farmers_info',['farmers'=>$farmers]);

    }

    public function farmer_deactive($id){

        $DeActivity="deactive";

        $farmer=farmer_login_save::find($id);

        $farmer['Activity']=$DeActivity;
        $farmer->save();

        return redirect('/Farmers');


    }

    public function f_login(){

        return view ('f_login');

    }

    public function f_login_check(Request $request){

        $f=farmer_login_save::where('email',$request->email)->first();
        $f2=farmer_login_save::where('password',$request->password)->first();

        if($f && $f2) {
            Session::put('f_name',$f['f_name']);
            return redirect('/Farmer/login/page');
        }

    }

    public function f_logout(){

       Session::flush();
        return redirect('/Farmer/login/page');

    }
    public function about (){
	    $path="demo.txt";
	    return response()->print($path);
    }

    public function add_cart(Request $request){
        $val=array('name'=>$request->p_name,
        'quentity'=>$request->quentity,
        'price'=>$request->price,
 );
        if(empty($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }
        array_push( $_SESSION['cart'],$val);

		return view('cart_view');

    }
}
