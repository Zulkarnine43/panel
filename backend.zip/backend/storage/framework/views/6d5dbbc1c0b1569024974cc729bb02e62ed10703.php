;

<?php $__env->startSection('body'); ?>

    
    <div class="row" style="margin-left: 200px">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 >Manage farmer Info</h3>
                    <table border="2px solid">
                        <tr>
                            <th>Sl No</th>
                            <th>farmers Name</th>
                            <th>email </th>
                            <th>mobile </th>
                            <th>district</th>
                            <th>zip_code</th>
                            <th>gender</th>
                            <th>Activity</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($farm_info->f_name); ?></td>
                                <td><?php echo e($farm_info->email); ?></td>
                                <td><?php echo e($farm_info->phone); ?></td>
                                <td><?php echo e($farm_info->district); ?></td>
                                <td><?php echo e($farm_info->zip_code); ?></td>
                                <td><?php echo e($farm_info->gender); ?></td>
                                <td>
                                    <a href="<?php echo e(route('farmer_deactive',['id'=>$farm_info->id])); ?>" onclick="return confirm('are you sure to deactive this')">Deactive</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>