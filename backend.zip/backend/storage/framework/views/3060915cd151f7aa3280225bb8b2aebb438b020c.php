
    ;

    <?php $__env->startSection('body'); ?>


        <div style="margin-left: 350px; margin-top: 80px">
            <h1><?php echo e(Session::get('regis_success')); ?></h1>

    <form method="post" action="<?php echo e(route('signup_form_save')); ?>">
	
	<?php echo csrf_field(); ?>
        <div>

            <label> Name:</label><br>
            <input type="text" name="f_name" placeholder="Enter your name ...">
        </div>
        <div>
            <label> Email:</label><br>
        <input type="email" name="email" placeholder="Enter your email ...">
        </div>
        <div>
            <label> phone:</label><br>
            <input type="tel" name="phone" placeholder="Enter your phone ...">
        </div>

        <div>
            <label> District:</label><br>
            <select name="district">
                <option value="0">select your district name</option>
                <option value="Dhaka">Dhaka</option>
                <option value="Rajshahi">Rajshahi</option>
                <option value="Khulna">Khulna</option>
                <option value="Sylhet">Sylhet</option>
                <option value="Chittagong">Chittagong</option>
            </select>
        </div>

        <div>
            <label> Zip code:</label><br>
            <input type="int" name="zip_code" placeholder="Enter your postal code ...">
        </div>


        <div>
            <label> Gender:</label><br>
            <input type="radio" name="gender" value="male">Male
            <input type="radio" name="gender" value="female">FeMale

        </div>


        <div>
            <label> password::</label><br>

           <input type="text" name="password" placeholder="Enter your password ..."><br>
        </div>


        <div>
            <label> Confirm_password:</label><br>
            <input type="text" name="confirm_password" placeholder="Enter your Confirm_password ..."><br>

        </div>

        
            
             

        

        <div>
            <input type="submit"  value="Submit">
        </div>


    </form>

        </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>