
;

<?php $__env->startSection('body'); ?>


    <div style="margin-left: 350px; margin-top: 80px">

<h1 style="color:green"><?php echo e(Session::get('verify_success')); ?></h1>


        <form method="post" action="<?php echo e(route('f_login_check')); ?>">

            <?php echo csrf_field(); ?>

            <div>
                <label> Email:</label><br>
                <input type="email" name="email" placeholder="Enter your email ...">
            </div>

            <div>
                <label> password::</label><br>

                <input type="text" name="password" placeholder="Enter your password ..."><br>
            </div>


            <div>
                <input type="submit"  value="Submit">
            </div>


        </form>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>