;


<?php $__env->startSection('body'); ?>

    <form method="post" action="<?php echo e(route('add_cart')); ?>">
        <?php echo csrf_field(); ?>
        <div class="gallery">
            <a target="_blank" href="">
                <img src="<?php echo e(url('public/myfile/images/ph1.png')); ?>" alt="images" style="width:200px; height: 200px">
            </a>
            <div class="desc"><h1 id="n"></h1>
                <p class="phone" id="p">phone</p>
                <p class="price" id="p">3000 TK</p>
                <input type="hidden" name="p_name" min="1" value="phone" >
                <input type="hidden" name="price" min="1" value="10000" >
                <input type="number" name="quentity" min="1" value="1" >
                <input type="submit" name="add_cart" value="ADD TO CART">
            </div>
        </div>
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>