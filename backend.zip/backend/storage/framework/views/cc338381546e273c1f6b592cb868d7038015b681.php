;


<?php $__env->startSection('body'); ?>

<table border="5px">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>quentity</th>
        <th>price</th>
        <th>Action</th>
    </tr>
    </thead>
    <?php ($i=0); ?>

    <?php $__currentLoopData = $_SESSION['cart']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
    <tr>
        <th><?php echo e($i++); ?></th>
        <th><?php echo e($value['name']); ?></th>
        <th><?php echo e($value['quentity']); ?></th>
        <th><?php echo e($value['price']*$value['quentity']); ?></th>
        <th><a>Edit</a></th>
    </tr>
    </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>