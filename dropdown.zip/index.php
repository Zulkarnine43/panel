<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	 <meta charset="utf-8">
    <title>home</title>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
	<div>
		<div style="background-color: rgb(106, 117, 117);">
		    <div class="social">
           <a href=""><span class="fab fa-facebook-f"></span></a>
              <a href="#"><span class="fab fa-twitter"></span></a>
              <a href=""><span class="fab fa-instagram"></span></a>
              <a href=""><span class="fab fa-youtube"></span></a>
                <p>+8801989419776</p>
                <p><a href="">zns601@gmail.com</a></p>
            </div>
        </div>
        <div>
        	<nav>
        	<ul>
        		<li class="menu"><a>Home</a>
                    <ul class="sub-menu">
                    	<li><a>h1</a></li>
                    	<li><a>h2</a></li>
                    </ul>
        		</li>
        		<li class="menu"><a>pages</a>
                       <ul class="sub-menu">
                    	<li><a>h1</a></li>
                    	<li><a>h2</a></li>
                    </ul>
        		</li>
                <li class="menu"><a>Features</a>
                       <ul class="sub-menu">
                    	<li><a>h1</a></li>
                    	<li><a>h2</a></li>
                    </ul>
                </li>
                <li class="menu"><a>Project</a>

                        <ul class="sub-menu">
                    	<li><a>h1</a></li>
                    	<li><a>h2</a></li>
                    </ul>
                </li>
                <li class="menu"><a>Blog</a>
                        <ul class="sub-menu">
                    	<li><a>h1</a></li>
                    	<li><a>h2</a></li>
                    </ul>
                </li>
                <li><a>Contact Us</a></li>
                <li><form><input type="text" name="search" placeholder="search">
                	<button><i class="fa fa-search" aria-hidden="true"></i></button></form></li>
        	</ul>

        	</nav>
        </div>
	</div>
	
</body>
</html>