<?php
session_start();
?>


<!-- ..................header area.............................. -->

  <?php
   @include("header.php");

  ?>

 <div style="color:red;"> <?php
  
  echo $_SESSION['msg'];
  ?></div>
<!-- ..................body Carousel.............................. -->



  <?php
   @include("progress_bar.php");

  ?>


<!-- ..................footer area.............................. -->



  <?php
   @include("footer.php");

  ?>





