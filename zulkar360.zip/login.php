<?php
session_start();

$con=mysqli_connect("localhost","zulkarni_shaon","zulkarnineshaon","zulkarni_login");

if(isset($_POST['btn'])){

$uname=$_POST['username'];
$pass=$_POST['password'];

$sql="INSERT INTO login(username,password) VALUES ('$uname','$pass')";

$result=mysqli_query($con,$sql);
if($result===TRUE){
    $_SESSION['msg']="successfully completed";
    header("Location:index.php");
}else{
    $_SESSION['msg2']=" there has a error";
     header("Location:login.php");
}
}


?>




	<link rel="stylesheet" type="text/css" href="css/style.css">


<!-- ..................header area.............................. -->

  <?php
   @include("header.php");

  ?>

<?php
echo $_SESSION['msg2'];
?>
<!-- ..................body Carousel.............................. -->
<header >
	<div class="main-header">
		<h1>Login</h1>
		<hr/>
		<h3>Welcome to e_agriculture</h3>
		<form action="" method="POST">

	<p><input type="text" name="username" placeholder="Username"></p>
	<p><input type="password" name="password" placeholder="Password"></p>
	<p><button type="submit" name="btn">Login</button></p>
	</form>
		
	</div>
		<div>
	<a href="signup.php">Register here</a>
	</div>

</header>


<!-- ..................footer area.............................. -->


  <?php
   @include("footer.php");

  ?>




