     <link rel="stylesheet" type="text/css"  href="css/about_us.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

<!-- ..................header area.............................. -->

	<?php
   @include("header.php");

	?>

<!-- ..................body area.............................. -->

    <div class="contain">
      <div class="image">
        <img src="img/photo.jpg">
      </div>
<div class="content">
        <div class="info">
          <h2>
Zulkar Nine</h2>
<span>Web Developer</span>
        </div>
</div>
<ul>
<li><a  class=" f" href="#"><span class="  fab fa-facebook-f"></span></a></li>
<li><a  class=" f" href="#"><span class=" fab fa-twitter"></span></a></li>
<li><a  class=" f" href="#"><span class=" fab fa-instagram"></span></a></li>
<li><a  class=" f" href="#"><span class=" fab fa-github"></span></a></li>
<li><a  class=" f" href="#"><span class=" fab fa-youtube"></span></a></li>
</ul>
</div>


<!-- ..................footer area.............................. -->

	<?php
   @include("footer.php");

	?>
