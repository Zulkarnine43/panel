
<link rel="stylesheet" type="text/css" href="css/contact.css">


<!-- ..................header area.............................. -->

  <?php
   @include("header.php");

  ?>


<!-- ..................body Carousel.............................. -->




<div class="containr">
  <form action="">

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name.."><br>

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name.."><br>

    <label for="country">Country</label>
    <select id="country" name="country">
         <option value="bangladesh">Bangladesh</option>
      <option value="india">India</option>
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
    </select><br>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea><br>

    <input type="submit" value="Submit"><br>

  </form>
</div>




<!-- ..................footer area.............................. -->


  <?php
   @include("footer.php");

  ?>





