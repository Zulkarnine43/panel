


<!-- ..................header area.............................. -->

  <?php
   @include("header.php");

  ?>


<!-- ..................body Carousel.............................. -->



  <?php
   @include("progress_bar.php");

  ?>


<!-- ..................footer area.............................. -->



  <?php
   @include("footer.php");

  ?>





