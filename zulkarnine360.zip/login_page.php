
<link rel="stylesheet" type="text/css" href="css/contact.css">


<!-- ..................header area.............................. -->

  <?php
   @include("header.php");

  ?>


<!-- ..................body Carousel.............................. -->


 <?php
   @include("login.php");

  ?>


<!-- ..................footer area.............................. -->


  <?php
   @include("footer.php");

  ?>





