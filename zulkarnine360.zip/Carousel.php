
    <link rel="stylesheet" type="text/css"  href="css/carousel.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>



<!-- ..................body area.............................. -->
<span class="bdy">
    <div class="cont">
      <div class="imgs">
        <img src="img/1.jpg">
        <img src="img/2.jpg">
        <img src="img/3.jpg">
        <img src="img/4.jpg">
      </div>
<div class="btm-slides">
        <span onclick="btm_slide(1)"></span>
        <span onclick="btm_slide(2)"></span>
        <span onclick="btm_slide(3)"></span>
        <span onclick="btm_slide(4)"></span>
        <span onclick="btm_slide(5)"></span>
      </div>
<div class="sliders left" onclick="side_slide(-1)">
        <span class="fas fa-angle-left"></span>
      </div>
<div class="sliders right" onclick="side_slide(1)">
        <span class="fas fa-angle-right"></span>
      </div>
</div>
</span>
<script>
      var indexValue = 1;
      showImg(indexValue);
      function btm_slide(e){showImg(indexValue = e);}
      function side_slide(e){showImg(indexValue += e);}
      function showImg(e){
        var i;
        const img = document.querySelectorAll('img');
        const slider = document.querySelectorAll('.btm-slides span');
        if(e > img.length){indexValue = 1}
        if(e < 1){indexValue = img.length}
        for(i = 0; i < img.length; i++){
          img[i].style.display = "none";
        }
        for(i = 0; i < slider.length; i++){
          slider[i].style.background = "rgba(255,255,255,0.1)";
        }
        img[indexValue-1].style.display = "block";
        slider[indexValue-1].style.background = "white";
      }
    </script>



