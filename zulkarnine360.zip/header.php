<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css"  href="css/search.css">
	<link rel="stylesheet" type="text/css"  href="css/header.css">
	<link rel="stylesheet" type="text/css"  href="css/footer.css">
   
</head>


<body>

	<!-- ..................search area.............................. -->

           <div class="s">
             <div class="search">
				<form class="search-form">
					<input type="text" placeholder="Search for books, authors, categories and more..">
					<input type="submit" value="Search">
				</form>
			  </div>
			</div>

<!-- ..................header area.............................. -->

	<div>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">E-Agriculture</label>
      <ul>
        <li><a class="active dropbtn" href="index.php">Home</a></li>
        <li><a href="about_us.php">About</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="about_us_update.php">Feedback</a></li>
         <li><a href="login_page.php">Login</a></li>
        <!--   <li> <div class="dropdown">-->
        <!--    <button class="dropbtn">COURSE</button>-->
        <!--    <div class="dropdown-content">-->
        <!--        <a href="">html</a>-->
        <!--        <a href="#">css</a>-->
        <!--    </div>-->
        <!--</div></li>-->
      </ul>
    </nav>
</div>
