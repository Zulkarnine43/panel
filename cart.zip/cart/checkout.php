
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>


<div id="cont">

<?php

session_start();
include("../db/config.php");
$WHEREiN=implode(',', $_SESSION['cart']);

$sql="SELECT * FROM product_info WHERE product_id in
($WHEREiN)";
$result=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($result)){

echo $row['0'];


}


?>

</div>




<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

