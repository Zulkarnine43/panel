
<!DOCTYPE html>
<html>
<head>
	<link href="{{url('public/asset/css/style.css')}}" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body class="bdy">

<div class="page">

     <nav>
      <div class="logo">
Zulkar Nine</div>
<label for="btn" class="icon">
        <span class="fa fa-bars"></span>
      </label>
      <input type="checkbox" id="btn">
      <ul>
<li><a href="#">Home</a></li>
<li>
          <label for="btn-1" class="show">Features +</label>
          <a href="#">Features</a>
          <input type="checkbox" id="btn-1">
          <ul>
<li><a href="#">Pages</a></li>
<li><a href="#">Elements</a></li>
<li><a href="#">Icons</a></li>
</ul>
</li>
<li>
          <label for="btn-2" class="show">Services +</label>
          <a href="#">Services</a>
          <input type="checkbox" id="btn-2">
          <ul>
<li><a href="#">Web Design</a></li>
<li><a href="#">App Design</a></li>
<li>
              <label for="btn-3" class="show">More +</label>
              <a href="#">More <span class="fa fa-plus"></span></a>
              <input type="checkbox" id="btn-3">
              <ul>
<li><a href="#">Submenu-1</a></li>
<li><a href="#">Submenu-2</a></li>
<li><a href="#">Submenu-3</a></li>
</ul>
</li>
</ul>
</li>
<li><a href="#">Portfolio</a></li>
<li><a href="#">Contact</a></li>
</ul>
</nav>

  </div>

</body>
</html>

