<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>


<body>
<header >
	<div class="main-header">
		<h1>Login</h1>
		<hr/>
		<h3>Welcome to e_agriculture</h3>

	<p><input type="text" name="username" placeholder="Username"></p>
	<p><input type="password" name="password" placeholder="Password"></p>
	<p><button>Login</button></p>
		
	</div>
</header>

	</body>
	</html>










</html>