<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css"  href="css/search.css">
	<link rel="stylesheet" type="text/css"  href="css/header.css">
	<link rel="stylesheet" type="text/css"  href="css/footer.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>


<body>

	<!-- ..................search area.............................. -->

           <div class="s">
             <div class="search">
				<form class="search-form">
					<input type="text" placeholder="Search for books, authors, categories and more..">
					<input type="submit" value="Search">
				</form>
			  </div>
			</div>

<!-- ..................header area.............................. -->

	<div>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">E-Agriculture</label>
      <ul>
        <li><a class="active" href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Feedback</a></li>
           <li> <div class="dropdown">
            <button class="dropbtn">COURSE</button>
            <div class="dropdown-content">
                <a href="">html</a>
                <a href="#">css</a>
            </div>
        </div></li>
      </ul>
    </nav>
</div>




<!-- ..................body Carousel.............................. -->


	
	<?php
   @include("Carousel.php");

	?>



<!-- ..................footer area.............................. -->

<div>
	<footer>
      <div class="main-content">
        <div class="left box">
          <h2>
About us</h2>
<div class="content">
            <p>
 you must learn web designing, web development, ui/ux designing, html css tutorial, hover animation and effects, javascript and jquery tutorial and related so on.</p>
<div class="social">
              <a href=""><span class="fab fa-facebook-f"></span></a>
              <a href="#"><span class="fab fa-twitter"></span></a>
              <a href=""><span class="fab fa-instagram"></span></a>
              <a href=""><span class="fab fa-youtube"></span></a>
            </div>
</div>
</div>

<div class="center box">
          <h2>
Address</h2>
<div class="content">
            <div class="place">
              <span class="fas fa-map-marker-alt"></span>
              <span class="text">Kolabagan, Dhaka</span>
            </div>
<div class="phone">
              <span class="fas fa-phone-alt"></span>
              <span class="text">+880-1989419776</span>
            </div>
<div class="email">
              <span class="fas fa-envelope"></span>
              <span class="text">zulkarninecity@gmail.com</span>
            </div>
</div>
</div>

<div class="right box">
          <h2>Contact us</h2>
<div class="content">
            <form action="#">
			
			
              <div class="email">
                <div class="text">Email *</div>
                    <input type="email" required></div>
			  
			  
                <div class="msg">
                 <div class="text">Message *</div>
                   <textarea id=".msgForm" rows="2" cols="25" required></textarea> </div>
              
                                <br />
                 <div class="btn">
                   <button type="submit">Send</button></div>
				   </form>
				   </div>
				   </div>
				   </div>


  <div class="bottom">
<center>
          <span class="credit">Created By <a href="">Zulkar Nine</a> | </span>
          <span class="far fa-copyright"></span> 2020 All rights reserved.
        </center>
</div>


  </footer>


</div>

	</body>
	</html>










</html>