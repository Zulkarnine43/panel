<?php
include("../db/config.php");
session_start();

$value=array(
'p_name'=>$_POST["p_name"],
'price'=>$_POST["price"],
'quentity'=>$_POST["quentity"],
);

if(empty($_SESSION['cart'])){
	$_SESSION['cart']=array();
}

array_push($_SESSION['cart'], $value);

// $count=count($_SESSION['cart']);
// echo $count;
?>



	<table border="2px">
		<thead>
			<tr>
				<th>Name</th>
				<th>price(per pics)</th>
				<th>quentity</th>
				<th>total-price</th>
				<th>Action</th>
			</tr>
		</thead>
		<?php $sum=0 ?>

<?php foreach ($_SESSION['cart'] as $key=>$value ) { ?>
		<tbody>
			<tr>
				<td><?php echo $value['p_name']  ?></td>
				<td><?php echo $value['price']  ?></td>
				<td><?php echo $value['quentity']  ?></td>
				<td><?php echo $value['quentity']*$value['price']  ?></td>
				<?php $sum+=$value['quentity']*$value['price'] ?>
			</tr>
		</tbody>
		<?php }  ?>
	</table>

<div>

	<h2>Total_taka</h2>

	<label><?php echo $sum ?></label>
</div>

   


